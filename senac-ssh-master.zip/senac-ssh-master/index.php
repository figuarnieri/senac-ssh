<?php
include_once 'includes/header.php';

include $app_login ? 'includes/index_login.php' : 'includes/index_logout.php';

include_once 'includes/footer.php';
?>