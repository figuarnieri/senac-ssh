new Maskfy('[data-mask]');

/*Maskfy({
    tag: '.mask-by-class',
    reverse: true,
    mask: '999.999.999,99',
    size: 3
});*/