new Scrolly('[data-scrolly]');

/*new Scrolly({
	tag: '[data-scrolly]',
	scrollAfter: function(tag, target){
		console.log(tag, target);
	}
});*/