<?php
include_once 'includes/header.php';
$product_edit = isset($_GET['edit']) && !empty($_GET['edit']) ? true : false;
if($product_edit){
	$product_sql = odbc_exec($db, '
		SELECT *
		FROM Produto
		WHERE idProduto = '.$_GET['edit']);
		$product = odbc_fetch_array($product_sql);
		//print_r($product);
}
?>
<link rel="stylesheet" href="dist/css/theme/pages/form.min.css">

<main class="main form wrap cf">
	<div class="pc-col-20">
		<span class="breadcrumb fl-l fa fa-list">Produto / <?php echo $product_edit ? 'Editar' : 'Cadastro' ?></span>
		<?php if($product_edit){ ?>
			<a href="includes/product_delete.php?id=<?php echo $_GET['edit']; ?>" class="fa fa-trash fl-r ta-c"></a>
		<?php } ?>
	</div>
	<form class="pc-col-20" action="includes/product_save.php" method="post">
		<?php if($product_edit){ ?>
			<input type="hidden" name="id" value="<?php echo $product['idProduto']?>">
		<?php } ?>
		<div class="form--box">
			<div class="cf va-m">
				<div class="pc-col-4 ta-r"><label class="form--label" for="Nome">Nome</label></div>
				<div class="pc-col-16"><input class="form--input" type="text" name="Nome" id="Nome" required="" value="<?php echo $product_edit ? utf8_encode($product['nomeProduto']) : ''?>"></div>
			</div>
			<div class="cf va-m">
				<div class="pc-col-4 ta-r"><label class="form--label" for="Descricao">Descrição</label></div>
				<div class="pc-col-16"><input class="form--input" type="text" name="Descricao" id="Descricao" value="<?php echo $product_edit ? utf8_encode($product['descProduto']) : ''?>"></div>
			</div>
			
			<div class="cf va-m">
				<div class="pc-col-20 ta-r">
					<button class="button" type="submit">Salvar</button>
				</div>
			</div>
		</div>
	</form>
</main>

<?php include_once 'includes/footer.php'; ?>